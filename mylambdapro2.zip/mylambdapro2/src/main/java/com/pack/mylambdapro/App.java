package com.pack.mylambdapro;

import java.util.Collections;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;

 
public class App implements RequestHandler<Object, GatewayResponse>
{

	@Override
	public GatewayResponse handleRequest(Object input, Context context) {
		

		String message="Hello From Java Gateway";
		System.out.println(message);
		
		
		GatewayResponse response= new GatewayResponse(message, 200,
				Collections.singletonMap("X-Powered-By", "Accenture-india"), 
				false);
		
		return response;
	}
    
       
    
}
