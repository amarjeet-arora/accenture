package com.app.aws.lambda;

 
 import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
 
 

@SpringBootApplication
public class SpringbootAwsLambdaApplication {

public static void main(String[] args) {
        SpringApplication.run(SpringbootAwsLambdaApplication.class, args);
    }

}
